fx_version 'adamant'

game 'gta5'

description 'Use /grantlicense [ID] [license]'

author '5quare Development | discord.gg/5quare'

lua54 'yes'

version '1.0'



server_scripts {
	'server.lua'
}

client_scripts {
	'client.lua'
}



